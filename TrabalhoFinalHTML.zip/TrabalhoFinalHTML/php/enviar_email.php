<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    $destinatario = "seuemail@exemplo.com";
    $headers = "From: " . $email;

    mail($destinatario, $assunto, $mensagem, $headers);

    echo "E-mail enviado com sucesso!";
}
?>
