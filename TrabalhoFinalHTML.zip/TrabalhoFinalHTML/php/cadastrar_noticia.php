<?php
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $conteudo = $_POST['conteudo'];
    $status = "ativa"; 

    $sql = "INSERT INTO noticias (titulo, conteudo, status) VALUES (:titulo, :conteudo, :status)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['titulo' => $titulo, 'conteudo' => $conteudo, 'status' => $status]);

    echo "Notícia cadastrada com sucesso!";
}
?>
