<?php
include 'conexao.php';

$sql = "SELECT titulo, conteudo FROM noticias WHERE status = 'ativa'";
$stmt = $pdo->query($sql);

while ($row = $stmt->fetch()) {
    echo "<h2>" . htmlspecialchars($row['titulo']) . "</h2>";
    echo "<p>" . htmlspecialchars($row['conteudo']) . "</p>";
}
?>
