<?php
include 'conexao.php';

$sql = "SELECT titulo, conteudo FROM noticias WHERE status = 'ativa'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<h2>" . htmlspecialchars($row['titulo']) . "</h2>";
        echo "<p>" . htmlspecialchars($row['conteudo']) . "</p>";
    }
} else {
    echo "Nenhuma notícia ativa encontrada.";
}

$conn->close();
?>

