<?php

require 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    
    $sql = "INSERT INTO mensagens_contato (email, assunto, mensagem) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    
    if ($stmt) {
        
        $stmt->bind_param("sss", $email, $assunto, $mensagem);

        if ($stmt->execute()) {
            echo "Mensagem recebida e salva no banco de dados!";
        } else {
            echo "Erro ao salvar mensagem: " . $stmt->error;
        }

       
        $stmt->close();
    } else {
        echo "Erro na preparação da consulta: " . $conn->error;
    }

    
    $conn->close();
}




