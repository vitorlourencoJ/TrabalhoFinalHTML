<?php
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $titulo = $_POST['titulo'];
    $conteudo = $_POST['conteudo'];
    $status = "ativa";

    $sql = "INSERT INTO noticias (titulo, conteudo, status) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sss", $titulo, $conteudo, $status);

        if ($stmt->execute()) {
            echo "Notícia cadastrada com sucesso!";
        } else {
            echo "Erro ao cadastrar notícia: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Erro na preparação da consulta: " . $conn->error;
    }

    $conn->close();
}
?>

