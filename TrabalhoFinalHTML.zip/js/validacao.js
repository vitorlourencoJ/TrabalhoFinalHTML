// Validação dos formulários
function validarCadastro() {
    let nome = document.getElementById("nome").value;
    let email = document.getElementById("email").value;

    if (nome === "" || email === "") {
        alert("Por favor, preencha todos os campos obrigatórios.");
        return false;
    }
    return true;
}

function validarContato() {
    let assunto = document.getElementById("assunto").value;
    let mensagem = document.getElementById("mensagem").value;

    if (assunto === "" || mensagem === "") {
        alert("Por favor, preencha todos os campos obrigatórios.");
        return false;
    }
    return true;
}
